/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/cdc/core" />
export * from './public_api';
