import * as i0 from "@angular/core";
import * as i1 from "./login-form/cdc-login-form.module";
export declare class CDCUserAccountModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCUserAccountModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CDCUserAccountModule, never, [typeof i1.CDCLoginFormModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CDCUserAccountModule>;
}
