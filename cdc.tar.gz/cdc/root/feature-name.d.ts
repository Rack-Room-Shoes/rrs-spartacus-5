export declare const CDC_FEATURE = "cdc";
export declare const CDC_CORE_FEATURE = "cdcCore";
