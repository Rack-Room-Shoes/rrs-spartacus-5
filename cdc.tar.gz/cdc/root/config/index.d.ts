export * from './cdc-config';
