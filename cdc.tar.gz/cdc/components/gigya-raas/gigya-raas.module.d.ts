import * as i0 from "@angular/core";
import * as i1 from "./gigya-raas.component";
import * as i2 from "@angular/common";
import * as i3 from "@spartacus/core";
export declare class GigyaRaasModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GigyaRaasModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GigyaRaasModule, [typeof i1.GigyaRaasComponent], [typeof i2.CommonModule, typeof i3.I18nModule, typeof i3.ConfigModule], [typeof i1.GigyaRaasComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GigyaRaasModule>;
}
