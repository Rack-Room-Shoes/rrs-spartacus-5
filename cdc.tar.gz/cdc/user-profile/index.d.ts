/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/cdc/user-profile" />
export * from './public_api';
