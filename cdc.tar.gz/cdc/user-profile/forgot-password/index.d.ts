export * from './cdc-forgot-password-component.service';
export * from './cdc-forgot-password.module';
