export * from './cdc-register-component.service';
export * from './cdc-register.module';
