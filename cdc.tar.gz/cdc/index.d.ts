/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/cdc" />
export * from './public_api';
