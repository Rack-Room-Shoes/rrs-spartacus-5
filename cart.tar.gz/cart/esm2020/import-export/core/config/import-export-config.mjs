/*
 * SPDX-FileCopyrightText: 2022 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
import { Injectable } from '@angular/core';
import { Config } from '@spartacus/core';
import * as i0 from "@angular/core";
export class ImportExportConfig {
}
ImportExportConfig.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.2.3", ngImport: i0, type: ImportExportConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
ImportExportConfig.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "14.2.3", ngImport: i0, type: ImportExportConfig, providedIn: 'root', useExisting: Config });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.2.3", ngImport: i0, type: ImportExportConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW1wb3J0LWV4cG9ydC1jb25maWcuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9mZWF0dXJlLWxpYnMvY2FydC9pbXBvcnQtZXhwb3J0L2NvcmUvY29uZmlnL2ltcG9ydC1leHBvcnQtY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7O0dBSUc7QUFFSCxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQzs7QUFRekMsTUFBTSxPQUFnQixrQkFBa0I7OytHQUFsQixrQkFBa0I7bUhBQWxCLGtCQUFrQixjQUgxQixNQUFNLGVBQ0wsTUFBTTsyRkFFQyxrQkFBa0I7a0JBSnZDLFVBQVU7bUJBQUM7b0JBQ1YsVUFBVSxFQUFFLE1BQU07b0JBQ2xCLFdBQVcsRUFBRSxNQUFNO2lCQUNwQiIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBTUERYLUZpbGVDb3B5cmlnaHRUZXh0OiAyMDIyIFNBUCBTcGFydGFjdXMgdGVhbSA8c3BhcnRhY3VzLXRlYW1Ac2FwLmNvbT5cbiAqXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbmZpZyB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5pbXBvcnQgeyBFeHBvcnRDb25maWcgfSBmcm9tICcuLi9tb2RlbC9leHBvcnQtZW50cmllcy5tb2RlbCc7XG5pbXBvcnQgeyBJbXBvcnRDb25maWcgfSBmcm9tICcuLi9tb2RlbC9pbXBvcnQtZW50cmllcy5jb25maWcnO1xuXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290JyxcbiAgdXNlRXhpc3Rpbmc6IENvbmZpZyxcbn0pXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgSW1wb3J0RXhwb3J0Q29uZmlnIHtcbiAgY2FydEltcG9ydEV4cG9ydD86IHtcbiAgICBmaWxlOiB7IHNlcGFyYXRvcjogc3RyaW5nIH07XG4gICAgaW1wb3J0PzogSW1wb3J0Q29uZmlnO1xuICAgIGV4cG9ydDogRXhwb3J0Q29uZmlnO1xuICB9O1xufVxuXG5kZWNsYXJlIG1vZHVsZSAnQHNwYXJ0YWN1cy9jb3JlJyB7XG4gIGludGVyZmFjZSBDb25maWcgZXh0ZW5kcyBJbXBvcnRFeHBvcnRDb25maWcge31cbn1cbiJdfQ==