/*
 * SPDX-FileCopyrightText: 2022 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
import { Injectable } from '@angular/core';
import { Config } from '@spartacus/core';
import * as i0 from "@angular/core";
export class QuickOrderConfig {
}
QuickOrderConfig.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.2.3", ngImport: i0, type: QuickOrderConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
QuickOrderConfig.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "14.2.3", ngImport: i0, type: QuickOrderConfig, providedIn: 'root', useExisting: Config });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.2.3", ngImport: i0, type: QuickOrderConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicXVpY2stb3JkZXItY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vZmVhdHVyZS1saWJzL2NhcnQvcXVpY2stb3JkZXIvcm9vdC9jb25maWcvcXVpY2stb3JkZXItY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7O0dBSUc7QUFFSCxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQzs7QUFNekMsTUFBTSxPQUFnQixnQkFBZ0I7OzZHQUFoQixnQkFBZ0I7aUhBQWhCLGdCQUFnQixjQUh4QixNQUFNLGVBQ0wsTUFBTTsyRkFFQyxnQkFBZ0I7a0JBSnJDLFVBQVU7bUJBQUM7b0JBQ1YsVUFBVSxFQUFFLE1BQU07b0JBQ2xCLFdBQVcsRUFBRSxNQUFNO2lCQUNwQiIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBTUERYLUZpbGVDb3B5cmlnaHRUZXh0OiAyMDIyIFNBUCBTcGFydGFjdXMgdGVhbSA8c3BhcnRhY3VzLXRlYW1Ac2FwLmNvbT5cbiAqXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbmZpZyB9IGZyb20gJ0BzcGFydGFjdXMvY29yZSc7XG5cbkBJbmplY3RhYmxlKHtcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxuICB1c2VFeGlzdGluZzogQ29uZmlnLFxufSlcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBRdWlja09yZGVyQ29uZmlnIHtcbiAgcXVpY2tPcmRlcj86IHtcbiAgICBzZWFyY2hGb3JtPzoge1xuICAgICAgZGlzcGxheVByb2R1Y3RJbWFnZXM6IGJvb2xlYW47XG4gICAgICBtYXhQcm9kdWN0czogbnVtYmVyO1xuICAgICAgbWluQ2hhcmFjdGVyc0JlZm9yZVJlcXVlc3Q6IG51bWJlcjtcbiAgICB9O1xuICAgIGxpc3Q/OiB7XG4gICAgICBoYXJkRGVsZXRlVGltZW91dDogbnVtYmVyO1xuICAgIH07XG4gIH07XG59XG5cbmRlY2xhcmUgbW9kdWxlICdAc3BhcnRhY3VzL2NvcmUnIHtcbiAgaW50ZXJmYWNlIENvbmZpZyBleHRlbmRzIFF1aWNrT3JkZXJDb25maWcge31cbn1cbiJdfQ==