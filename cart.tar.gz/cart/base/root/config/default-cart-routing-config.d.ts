import { RoutingConfig } from '@spartacus/core';
export declare const defaultCartRoutingConfig: RoutingConfig;
