import { CartConfig } from './cart-config';
export declare const defaultCartConfig: CartConfig;
