import '@spartacus/storefront';
declare module '@spartacus/storefront' {
    const enum LAUNCH_CALLER {
        CLEAR_CART = "CLEAR_CART",
        ADDED_TO_CART = "ADDED_TO_CART"
    }
}
