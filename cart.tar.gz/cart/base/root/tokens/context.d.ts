import { InjectionToken } from '@angular/core';
export declare const ActiveCartOrderEntriesContextToken: InjectionToken<unknown>;
