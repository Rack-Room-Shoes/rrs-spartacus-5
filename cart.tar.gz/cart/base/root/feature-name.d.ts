export declare const CART_BASE_FEATURE = "cartBase";
export declare const CART_BASE_CORE_FEATURE = "cartBaseCore";
export declare const MINI_CART_FEATURE = "miniCart";
export declare const ADD_TO_CART_FEATURE = "addToCart";
