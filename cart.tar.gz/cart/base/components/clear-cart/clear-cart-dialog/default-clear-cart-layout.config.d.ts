import { LayoutConfig } from '@spartacus/storefront';
export declare const defaultClearCartLayoutConfig: LayoutConfig;
