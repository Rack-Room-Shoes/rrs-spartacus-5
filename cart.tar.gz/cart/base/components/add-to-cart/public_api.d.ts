export * from './add-to-cart.component';
export * from './add-to-cart.module';
