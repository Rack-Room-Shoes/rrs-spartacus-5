/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/cart/base/components/add-to-cart" />
export * from './public_api';
