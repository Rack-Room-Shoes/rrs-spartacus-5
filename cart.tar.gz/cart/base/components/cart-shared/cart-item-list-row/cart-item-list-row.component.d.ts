import { CartItemComponent } from '../cart-item/cart-item.component';
import * as i0 from "@angular/core";
export declare class CartItemListRowComponent extends CartItemComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartItemListRowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartItemListRowComponent, "[cx-cart-item-list-row], cx-cart-item-list-row", never, {}, {}, never, never, false>;
}
