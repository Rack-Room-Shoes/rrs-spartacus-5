import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const cartBaseTranslations: TranslationResources;
export declare const cartBaseTranslationChunksConfig: TranslationChunksConfig;
