/*
 * SPDX-FileCopyrightText: 2022 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const wishlist = {
    wishlist: {
        empty: 'No products in your wish list yet',
        itemRemoved: 'Selected item has been removed.',
        caption: 'Wish list contents.',
    },
};

/*
 * SPDX-FileCopyrightText: 2022 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    wishlist,
};

/*
 * SPDX-FileCopyrightText: 2022 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const wishListTranslations = {
    en,
};
const wishListTranslationChunksConfig = {
    wishlist: ['wishlist'],
};

/*
 * SPDX-FileCopyrightText: 2022 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { wishListTranslationChunksConfig, wishListTranslations };
//# sourceMappingURL=spartacus-cart-wish-list-assets.mjs.map
