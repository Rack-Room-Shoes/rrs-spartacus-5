import * as i0 from "@angular/core";
export declare class AepModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AepModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AepModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AepModule>;
}
