import { PersonalizationConfig } from './personalization-config';
export declare const defaultPersonalizationConfig: PersonalizationConfig;
