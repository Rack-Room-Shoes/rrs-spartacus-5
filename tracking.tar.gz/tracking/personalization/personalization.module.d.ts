import * as i0 from "@angular/core";
import * as i1 from "@spartacus/tracking/personalization/core";
export declare class PersonalizationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PersonalizationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PersonalizationModule, never, [typeof i1.PersonalizationCoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PersonalizationModule>;
}
