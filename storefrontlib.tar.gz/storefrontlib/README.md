# Spartacus Storefront

Spartacus Storefront is a package that you can include in your application, which allows you to add default storefront features.

The Spartacus Storefront is extendable and upgradable by changing the version of the library you are using. Furthermore, the storefront can be styled by using the [Spartacus Styles](https://www.npmjs.com/package/@spartacus/styles) package.

For more informations, see [Spartacus](https://github.com/SAP/spartacus).

#### Related projects

[Spartacus Styles](https://www.npmjs.com/package/@spartacus/styles)
