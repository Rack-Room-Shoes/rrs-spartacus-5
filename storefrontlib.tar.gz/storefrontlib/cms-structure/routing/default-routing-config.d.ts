import { RoutesConfig, RoutingConfig } from '@spartacus/core';
export declare const defaultStorefrontRoutesConfig: RoutesConfig;
export declare const defaultRoutingConfig: RoutingConfig;
