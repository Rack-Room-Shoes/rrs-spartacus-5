import * as i0 from "@angular/core";
export declare class CmsRouteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsRouteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CmsRouteModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CmsRouteModule>;
}
