import { Injector } from '@angular/core';
export declare function addCmsRoute(injector: Injector): () => void;
