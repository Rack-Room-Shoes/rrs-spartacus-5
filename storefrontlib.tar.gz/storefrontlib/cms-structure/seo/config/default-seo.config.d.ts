import { SeoConfig } from './seo.config';
export declare const defaultSeoConfig: SeoConfig;
