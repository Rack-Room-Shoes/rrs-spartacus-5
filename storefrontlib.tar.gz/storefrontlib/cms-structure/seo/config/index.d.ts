export * from './default-seo.config';
export * from './seo.config';
