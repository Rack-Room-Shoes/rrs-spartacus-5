import * as i0 from "@angular/core";
import * as i1 from "./outlet-ref.directive";
import * as i2 from "@angular/common";
export declare class OutletRefModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OutletRefModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OutletRefModule, [typeof i1.OutletRefDirective], [typeof i2.CommonModule], [typeof i1.OutletRefDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OutletRefModule>;
}
