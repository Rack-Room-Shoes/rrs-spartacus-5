import { OnNavigateConfig } from './on-navigate-config';
export declare const defaultOnNavigateConfig: OnNavigateConfig;
