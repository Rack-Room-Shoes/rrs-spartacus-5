import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const dpTranslations: TranslationResources;
export declare const dpTranslationChunksConfig: TranslationChunksConfig;
