import * as i0 from "@angular/core";
import * as i1 from "./checkout/dp-checkout.module";
export declare class DigitalPaymentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DigitalPaymentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DigitalPaymentsModule, never, [typeof i1.DpCheckoutModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DigitalPaymentsModule>;
}
