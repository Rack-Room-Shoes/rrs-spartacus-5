export interface DpPaymentRequest {
    url?: string;
    sessionId?: string;
    signature?: string;
}
