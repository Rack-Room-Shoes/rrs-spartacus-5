export * from './occ-digital-payments-endpoint.config';
export * from './occ-digital-payments-endpoint.model';
