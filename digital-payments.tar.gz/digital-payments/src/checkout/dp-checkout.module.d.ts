import * as i0 from "@angular/core";
import * as i1 from "./cms-components/dp-payment-method/dp-payment-method.module";
export declare class DpCheckoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DpCheckoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DpCheckoutModule, never, [typeof i1.DpPaymentMethodModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DpCheckoutModule>;
}
