export declare const CURRENT_CART = "current";
export declare const DP_CARD_REGISTRATION_STATUS = "x-card-registration-status";
