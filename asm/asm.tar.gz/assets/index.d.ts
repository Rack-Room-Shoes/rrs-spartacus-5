/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/asm/assets" />
export * from './public_api';
