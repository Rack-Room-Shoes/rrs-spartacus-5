import { Action } from '@ngrx/store';
import { AsmUi } from '../../models/asm.models';
export declare const initialState: AsmUi;
export declare function reducer(state: AsmUi | undefined, action: Action): AsmUi;
