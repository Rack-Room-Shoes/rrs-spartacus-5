/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/asm/root" />
export * from './public_api';
