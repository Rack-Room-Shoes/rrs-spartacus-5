import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare class AsmOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmOccModule>;
}
