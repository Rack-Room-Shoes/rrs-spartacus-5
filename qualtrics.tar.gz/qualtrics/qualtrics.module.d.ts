import * as i0 from "@angular/core";
import * as i1 from "@spartacus/qualtrics/components";
export declare class QualtricsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QualtricsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QualtricsModule, never, [typeof i1.QualtricsComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QualtricsModule>;
}
