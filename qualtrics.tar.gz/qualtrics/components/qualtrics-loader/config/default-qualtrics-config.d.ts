import { QualtricsConfig } from './qualtrics-config';
export declare const defaultQualtricsConfig: QualtricsConfig;
