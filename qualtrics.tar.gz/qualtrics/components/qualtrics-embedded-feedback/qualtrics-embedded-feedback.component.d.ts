import * as i0 from "@angular/core";
export declare class QualtricsEmbeddedFeedbackComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<QualtricsEmbeddedFeedbackComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QualtricsEmbeddedFeedbackComponent, "cx-qualtrics-embedded-feedback", never, {}, {}, never, never, false>;
}
