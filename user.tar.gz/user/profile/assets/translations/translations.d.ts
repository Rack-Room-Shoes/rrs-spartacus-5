import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const userProfileTranslations: TranslationResources;
export declare const userProfileTranslationChunksConfig: TranslationChunksConfig;
