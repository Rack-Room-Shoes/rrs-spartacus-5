export * from './default-occ-user-profile-endpoint.config';
export * from './occ-user-profile-endpoint.model';
