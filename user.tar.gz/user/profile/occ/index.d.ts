/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/user/profile/occ" />
export * from './public_api';
