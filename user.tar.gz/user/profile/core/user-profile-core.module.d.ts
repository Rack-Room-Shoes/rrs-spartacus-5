import * as i0 from "@angular/core";
export declare class UserProfileCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserProfileCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserProfileCoreModule>;
}
