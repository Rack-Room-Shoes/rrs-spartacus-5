/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/user/profile/core" />
export * from './public_api';
