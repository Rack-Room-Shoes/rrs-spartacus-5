export * from './register.component';
export * from './register.module';
export * from './register-component.service';
