export * from './update-email-component.service';
export * from './update-email.component';
export * from './update-email.module';
