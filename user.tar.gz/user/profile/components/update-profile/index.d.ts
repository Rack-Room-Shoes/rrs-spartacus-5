export * from './update-profile-component.service';
export * from './update-profile.component';
export * from './update-profile.module';
