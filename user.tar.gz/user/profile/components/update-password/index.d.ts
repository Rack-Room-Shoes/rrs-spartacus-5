export * from './update-password-component.service';
export * from './update-password.component';
export * from './update-password.module';
