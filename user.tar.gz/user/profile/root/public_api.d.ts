export * from './facade/index';
export * from './feature-name';
export * from './model/index';
export * from './user-profile-root.module';
/** AUGMENTABLE_TYPES_START */
export { Title, UserSignUp } from './model/user-profile.model';
/** AUGMENTABLE_TYPES_END */
