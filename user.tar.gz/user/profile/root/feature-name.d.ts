export declare const USER_PROFILE_FEATURE = "userProfile";
export declare const USER_PROFILE_CORE_FEATURE = "userProfileCore";
