/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/user/account" />
export * from './public_api';
