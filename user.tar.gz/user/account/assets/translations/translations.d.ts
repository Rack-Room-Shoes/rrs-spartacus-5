import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const userAccountTranslations: TranslationResources;
export declare const userAccountTranslationChunksConfig: TranslationChunksConfig;
