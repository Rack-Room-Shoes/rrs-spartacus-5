/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/user/account/assets" />
export * from './public_api';
