export interface User {
    displayUid?: string;
    firstName?: string;
    lastName?: string;
    name?: string;
    uid?: string;
}
