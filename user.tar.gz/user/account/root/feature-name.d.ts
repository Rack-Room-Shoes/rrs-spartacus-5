export declare const USER_ACCOUNT_FEATURE = "userAccount";
export declare const USER_ACCOUNT_CORE_FEATURE = "userAccountCore";
