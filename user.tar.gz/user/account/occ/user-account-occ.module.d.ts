import * as i0 from "@angular/core";
export declare class UserAccountOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAccountOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAccountOccModule>;
}
