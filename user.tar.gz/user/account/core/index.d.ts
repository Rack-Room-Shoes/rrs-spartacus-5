/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/user/account/core" />
export * from './public_api';
