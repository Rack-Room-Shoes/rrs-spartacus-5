import * as i0 from "@angular/core";
export declare class UserAccountCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAccountCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAccountCoreModule>;
}
