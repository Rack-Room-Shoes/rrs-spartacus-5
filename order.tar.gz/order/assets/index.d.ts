/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/order/assets" />
export * from './public_api';
