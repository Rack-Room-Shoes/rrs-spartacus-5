import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const orderTranslations: TranslationResources;
export declare const orderTranslationChunksConfig: TranslationChunksConfig;
