export declare const completedValues: string[];
export declare const cancelledValues: string[];
