import { LayoutConfig } from '@spartacus/storefront';
export declare const defaultReplenishmentOrderCancellationLayoutConfig: LayoutConfig;
