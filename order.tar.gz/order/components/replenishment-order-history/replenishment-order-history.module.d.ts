import * as i0 from "@angular/core";
import * as i1 from "./replenishment-order-history.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/router";
import * as i4 from "@spartacus/storefront";
import * as i5 from "@spartacus/core";
export declare class ReplenishmentOrderHistoryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderHistoryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReplenishmentOrderHistoryModule, [typeof i1.ReplenishmentOrderHistoryComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof i4.ListNavigationModule, typeof i5.UrlModule, typeof i5.I18nModule], [typeof i1.ReplenishmentOrderHistoryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReplenishmentOrderHistoryModule>;
}
