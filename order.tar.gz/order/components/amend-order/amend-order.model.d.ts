export declare enum AmendOrderType {
    CANCEL = 0,
    RETURN = 1
}
