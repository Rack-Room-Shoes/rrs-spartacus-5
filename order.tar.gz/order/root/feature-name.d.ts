export declare const ORDER_FEATURE = "order";
export declare const ORDER_CORE_FEATURE = "orderCore";
