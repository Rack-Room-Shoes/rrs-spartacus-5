import '@spartacus/storefront';
declare module '@spartacus/storefront' {
    const enum LAUNCH_CALLER {
        CONSIGNMENT_TRACKING = "CONSIGNMENT_TRACKING"
    }
}
