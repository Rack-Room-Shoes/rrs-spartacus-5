import { InjectionToken } from '@angular/core';
export declare const OrderDetailsOrderEntriesContextToken: InjectionToken<unknown>;
export declare const OrderConfirmationOrderEntriesContextToken: InjectionToken<unknown>;
