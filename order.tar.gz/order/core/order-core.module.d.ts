import * as i0 from "@angular/core";
import * as i1 from "./store/order-store.module";
export declare class OrderCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderCoreModule, never, [typeof i1.OrderStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderCoreModule>;
}
