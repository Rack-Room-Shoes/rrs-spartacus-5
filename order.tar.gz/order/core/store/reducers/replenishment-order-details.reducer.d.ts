import { ReplenishmentOrder } from '@spartacus/order/root';
import { OrderActions } from '../actions/index';
export declare const initialState: ReplenishmentOrder;
export declare function reducer(state: ReplenishmentOrder | undefined, action: OrderActions.ReplenishmentOrderDetailsAction): ReplenishmentOrder;
