import { ReturnRequestList } from '@spartacus/order/root';
import { OrderActions } from '../actions/index';
export declare const initialState: ReturnRequestList;
export declare function reducer(state: ReturnRequestList | undefined, action: OrderActions.OrderReturnRequestAction): ReturnRequestList;
