import * as i0 from "@angular/core";
import * as i1 from "@ngrx/effects";
import * as i2 from "@ngrx/store";
export declare class OrderStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderStoreModule, never, [typeof i1.EffectsFeatureModule, typeof i2.StoreFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderStoreModule>;
}
