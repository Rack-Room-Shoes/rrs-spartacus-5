import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const checkoutScheduledReplenishmentTranslations: TranslationResources;
export declare const checkoutScheduledReplenishmentTranslationChunksConfig: TranslationChunksConfig;
