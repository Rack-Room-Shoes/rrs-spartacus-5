export declare const checkoutScheduledReplenishment: {
    checkoutScheduledReplenishment: {
        autoReplenishOrder: string;
        orderType_PLACE_ORDER: string;
        orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
        every: string;
        recurrencePeriodType_DAILY: string;
        recurrencePeriodType_WEEKLY: string;
        recurrencePeriodType_MONTHLY: string;
        dayOfMonth: string;
        startOn: string;
        repeatOnDays: string;
    };
};
