/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/checkout/scheduled-replenishment/assets" />
export * from './public_api';
