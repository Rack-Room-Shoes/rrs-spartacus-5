import * as i0 from "@angular/core";
import * as i1 from "@spartacus/checkout/scheduled-replenishment/components";
export declare class CheckoutScheduledReplenishmentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduledReplenishmentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutScheduledReplenishmentModule, never, [typeof i1.CheckoutScheduledReplenishmentComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutScheduledReplenishmentModule>;
}
