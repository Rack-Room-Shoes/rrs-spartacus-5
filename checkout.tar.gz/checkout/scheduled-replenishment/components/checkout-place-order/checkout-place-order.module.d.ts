import * as i0 from "@angular/core";
import * as i1 from "./checkout-place-order.component";
import * as i2 from "@spartacus/storefront";
import * as i3 from "@angular/common";
import * as i4 from "@angular/router";
import * as i5 from "@spartacus/core";
import * as i6 from "@angular/forms";
export declare class CheckoutScheduledReplenishmentPlaceOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduledReplenishmentPlaceOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutScheduledReplenishmentPlaceOrderModule, [typeof i1.CheckoutScheduledReplenishmentPlaceOrderComponent], [typeof i2.AtMessageModule, typeof i3.CommonModule, typeof i4.RouterModule, typeof i5.UrlModule, typeof i5.I18nModule, typeof i6.ReactiveFormsModule], [typeof i1.CheckoutScheduledReplenishmentPlaceOrderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutScheduledReplenishmentPlaceOrderModule>;
}
