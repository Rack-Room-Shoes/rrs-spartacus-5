import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "./checkout-schedule-replenishment-order/checkout-schedule-replenishment-order.module";
import * as i3 from "./checkout-place-order/checkout-place-order.module";
export declare class CheckoutScheduledReplenishmentComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduledReplenishmentComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutScheduledReplenishmentComponentsModule, never, [typeof i1.CommonModule, typeof i2.CheckoutScheduleReplenishmentOrderModule, typeof i3.CheckoutScheduledReplenishmentPlaceOrderModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutScheduledReplenishmentComponentsModule>;
}
