import { CheckoutScheduledReplenishmentEventListener } from './checkout-scheduled-replenishment-event.listener';
import * as i0 from "@angular/core";
export declare class CheckoutScheduledReplenishmentEventModule {
    constructor(_checkoutScheduledReplenishmentEventListener: CheckoutScheduledReplenishmentEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduledReplenishmentEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutScheduledReplenishmentEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutScheduledReplenishmentEventModule>;
}
