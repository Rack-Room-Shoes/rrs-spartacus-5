import * as i0 from "@angular/core";
export declare class CheckoutCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutCoreModule>;
}
