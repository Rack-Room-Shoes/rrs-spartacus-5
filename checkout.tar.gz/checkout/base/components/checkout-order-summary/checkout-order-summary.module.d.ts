import * as i0 from "@angular/core";
import * as i1 from "./checkout-order-summary.component";
import * as i2 from "@angular/common";
import * as i3 from "@spartacus/storefront";
export declare class CheckoutOrderSummaryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutOrderSummaryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutOrderSummaryModule, [typeof i1.CheckoutOrderSummaryComponent], [typeof i2.CommonModule, typeof i3.OutletModule], [typeof i1.CheckoutOrderSummaryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutOrderSummaryModule>;
}
