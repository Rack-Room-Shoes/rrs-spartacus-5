import * as i0 from "@angular/core";
import * as i1 from "./checkout-progress-mobile-bottom.component";
import * as i2 from "@angular/common";
import * as i3 from "@spartacus/core";
import * as i4 from "@angular/router";
export declare class CheckoutProgressMobileBottomModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutProgressMobileBottomModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutProgressMobileBottomModule, [typeof i1.CheckoutProgressMobileBottomComponent], [typeof i2.CommonModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof i4.RouterModule], [typeof i1.CheckoutProgressMobileBottomComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutProgressMobileBottomModule>;
}
