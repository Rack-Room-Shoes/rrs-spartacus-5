import * as i0 from "@angular/core";
import * as i1 from "./checkout-orchestrator.component";
import * as i2 from "@angular/common";
export declare class CheckoutOrchestratorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutOrchestratorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutOrchestratorModule, [typeof i1.CheckoutOrchestratorComponent], [typeof i2.CommonModule], [typeof i1.CheckoutOrchestratorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutOrchestratorModule>;
}
