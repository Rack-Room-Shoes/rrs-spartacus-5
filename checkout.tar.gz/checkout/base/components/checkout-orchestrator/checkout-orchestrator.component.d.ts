import * as i0 from "@angular/core";
export declare class CheckoutOrchestratorComponent {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutOrchestratorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutOrchestratorComponent, "cx-checkout-orchestrator", never, {}, {}, never, never, false>;
}
