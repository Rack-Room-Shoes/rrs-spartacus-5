import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare class CheckoutOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutOccModule>;
}
