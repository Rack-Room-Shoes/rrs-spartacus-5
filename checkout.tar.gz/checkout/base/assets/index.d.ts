/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/checkout/base/assets" />
export * from './public_api';
