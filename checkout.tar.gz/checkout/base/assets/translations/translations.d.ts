import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const checkoutTranslations: TranslationResources;
export declare const checkoutTranslationChunksConfig: TranslationChunksConfig;
