import { CheckoutConfig } from './checkout-config';
export declare const defaultCheckoutConfig: CheckoutConfig;
