import { RoutingConfig } from '@spartacus/core';
export declare const defaultCheckoutRoutingConfig: RoutingConfig;
