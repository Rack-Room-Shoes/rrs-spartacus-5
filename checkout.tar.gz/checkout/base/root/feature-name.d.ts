export declare const CHECKOUT_FEATURE = "checkout";
export declare const CHECKOUT_CORE_FEATURE = "checkoutCore";
