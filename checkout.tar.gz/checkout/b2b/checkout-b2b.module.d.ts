import * as i0 from "@angular/core";
import * as i1 from "@spartacus/checkout/b2b/components";
import * as i2 from "@spartacus/checkout/b2b/core";
import * as i3 from "@spartacus/checkout/b2b/occ";
export declare class CheckoutB2BModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutB2BModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutB2BModule, never, [typeof i1.CheckoutB2BComponentsModule, typeof i2.CheckoutB2BCoreModule, typeof i3.CheckoutB2BOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutB2BModule>;
}
