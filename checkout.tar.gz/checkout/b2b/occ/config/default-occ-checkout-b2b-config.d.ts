import { OccConfig } from '@spartacus/core';
export declare const defaultOccCheckoutB2BConfig: OccConfig;
