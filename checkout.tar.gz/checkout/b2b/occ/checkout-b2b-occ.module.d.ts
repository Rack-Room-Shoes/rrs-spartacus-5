import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare class CheckoutB2BOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutB2BOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutB2BOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutB2BOccModule>;
}
