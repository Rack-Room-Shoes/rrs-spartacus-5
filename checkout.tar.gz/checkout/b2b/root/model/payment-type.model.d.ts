export declare enum B2BPaymentTypeEnum {
    ACCOUNT_PAYMENT = "ACCOUNT",
    CARD_PAYMENT = "CARD"
}
