/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/checkout/b2b/root" />
export * from './public_api';
