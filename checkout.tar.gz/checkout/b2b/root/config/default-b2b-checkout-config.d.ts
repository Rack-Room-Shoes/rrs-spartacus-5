import { CheckoutConfig } from '@spartacus/checkout/base/root';
export declare const defaultB2BCheckoutConfig: CheckoutConfig;
