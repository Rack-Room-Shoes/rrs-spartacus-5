import * as i0 from "@angular/core";
import * as i1 from "./checkout-cost-center.component";
import * as i2 from "@angular/common";
import * as i3 from "@spartacus/core";
export declare class CheckoutCostCenterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutCostCenterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutCostCenterModule, [typeof i1.CheckoutCostCenterComponent], [typeof i2.CommonModule, typeof i3.I18nModule, typeof i3.ConfigModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutCostCenterModule>;
}
