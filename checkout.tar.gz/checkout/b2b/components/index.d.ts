/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/checkout/b2b/components" />
export * from './public_api';
