import * as i0 from "@angular/core";
export declare class CheckoutB2BCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutB2BCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutB2BCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutB2BCoreModule>;
}
