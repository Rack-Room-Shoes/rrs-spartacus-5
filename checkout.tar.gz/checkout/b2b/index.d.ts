/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/checkout/b2b" />
export * from './public_api';
