import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const checkoutB2BTranslations: TranslationResources;
export declare const checkoutB2BTranslationChunksConfig: TranslationChunksConfig;
