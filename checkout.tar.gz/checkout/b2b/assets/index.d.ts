/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/checkout/b2b/assets" />
export * from './public_api';
