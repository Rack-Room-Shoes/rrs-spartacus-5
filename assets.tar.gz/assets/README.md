# Assets

Assets library provides static resources for i18n, fonts, icons, etc. Example usage:

`import { translations } from '@spartacus/assets';`