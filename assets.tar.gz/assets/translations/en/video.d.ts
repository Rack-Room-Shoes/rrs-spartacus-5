export declare const video: {
    player: {
        label: string;
    };
};
