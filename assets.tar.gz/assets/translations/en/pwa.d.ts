export declare const pwa: {
    pwa: {
        addToHomeScreenDescription: string;
        noInstallationNeeded: string;
        fastAccessToApplication: string;
        addToHomeScreen: string;
        addedToHomeScreen: string;
    };
};
