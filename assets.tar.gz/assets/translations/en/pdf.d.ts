export declare const pdf: {
    pdf: {
        defaultTitle: string;
    };
};
