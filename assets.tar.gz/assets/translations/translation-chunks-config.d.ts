export interface TranslationChunksConfig {
    [chunk: string]: string[];
}
export declare const translationChunksConfig: TranslationChunksConfig;
