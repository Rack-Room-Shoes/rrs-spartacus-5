import * as i0 from "@angular/core";
export declare class EpdVisualizationCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EpdVisualizationCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EpdVisualizationCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EpdVisualizationCoreModule>;
}
