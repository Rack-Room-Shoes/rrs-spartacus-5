import { VisualizationInfo } from '@spartacus/epd-visualization/root';
export interface LookupVisualizationsResponse {
    visualizations?: VisualizationInfo[];
}
