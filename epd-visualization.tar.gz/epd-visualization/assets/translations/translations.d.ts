import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const epdVisualizationTranslations: TranslationResources;
export declare const epdVisualizationTranslationChunksConfig: TranslationChunksConfig;
