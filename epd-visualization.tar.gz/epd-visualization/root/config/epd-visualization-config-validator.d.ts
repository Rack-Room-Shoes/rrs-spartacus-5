import { EpdVisualizationConfig } from './epd-visualization-config';
export declare function epdVisualizationConfigValidator(epdVisualizationConfig: EpdVisualizationConfig): string | void;
