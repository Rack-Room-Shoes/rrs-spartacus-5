import { EpdVisualizationConfig } from '../config/epd-visualization-config';
export declare function getEpdVisualizationDefaultConfig(): EpdVisualizationConfig;
