export declare function getUrl(urlString: string): URL | null;
export declare function isHttpOrHttps(url: URL): boolean;
