export interface UsageIdDefinition {
    name?: string;
    source: string;
    category: string;
    keyName: string;
}
