export interface UsageId {
    name: string;
    keys: UsageIdKey[];
}
export interface UsageIdKey {
    name: String;
    value: String;
}
