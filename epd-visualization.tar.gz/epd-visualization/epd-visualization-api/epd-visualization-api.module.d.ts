import * as i0 from "@angular/core";
export declare class EpdVisualizationApiModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EpdVisualizationApiModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EpdVisualizationApiModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EpdVisualizationApiModule>;
}
