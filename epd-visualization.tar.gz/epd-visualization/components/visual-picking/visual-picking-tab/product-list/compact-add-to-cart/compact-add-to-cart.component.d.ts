import { AddToCartComponent } from '@spartacus/cart/base/components/add-to-cart';
import * as i0 from "@angular/core";
export declare class CompactAddToCartComponent extends AddToCartComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CompactAddToCartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CompactAddToCartComponent, "cx-epd-visualization-compact-add-to-cart", never, {}, {}, never, never, false>;
}
