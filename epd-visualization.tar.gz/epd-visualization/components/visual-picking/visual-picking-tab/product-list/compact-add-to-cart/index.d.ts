export * from './compact-add-to-cart.component';
export * from './compact-add-to-cart.module';
