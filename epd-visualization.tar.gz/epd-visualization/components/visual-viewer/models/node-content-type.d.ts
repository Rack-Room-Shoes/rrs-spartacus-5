export declare enum NodeContentType {
    Annotation = "Annotation",
    Background = "Background",
    Hotspot = "Hotspot",
    Reference = "Reference",
    Regular = "Regular",
    Symbol = "Symbol"
}
