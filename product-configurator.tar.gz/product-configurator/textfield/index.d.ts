/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/product-configurator/textfield" />
export * from './public_api';
