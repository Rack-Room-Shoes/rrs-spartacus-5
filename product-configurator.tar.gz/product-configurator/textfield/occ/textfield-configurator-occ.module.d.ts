import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@spartacus/core";
export declare class TextfieldConfiguratorOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextfieldConfiguratorOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextfieldConfiguratorOccModule, never, [typeof i1.CommonModule, typeof i2.ConfigModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextfieldConfiguratorOccModule>;
}
