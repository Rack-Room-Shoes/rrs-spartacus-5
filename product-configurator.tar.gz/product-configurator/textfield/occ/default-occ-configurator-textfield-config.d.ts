import { OccConfig } from '@spartacus/core';
export declare function defaultOccConfiguratorTextfieldConfigFactory(): OccConfig;
