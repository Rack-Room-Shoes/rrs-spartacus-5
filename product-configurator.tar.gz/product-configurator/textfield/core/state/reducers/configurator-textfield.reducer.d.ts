import { ConfiguratorTextfield } from '../../model/configurator-textfield.model';
import { ConfiguratorActions } from '../actions/configurator-textfield.action';
export declare const initialState: ConfiguratorTextfield.Configuration;
export declare function reducer(state: ConfiguratorTextfield.Configuration | undefined, action: ConfiguratorActions): ConfiguratorTextfield.Configuration;
