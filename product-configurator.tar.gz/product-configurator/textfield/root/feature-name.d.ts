export declare const PRODUCT_CONFIGURATOR_TEXTFIELD_FEATURE = "productConfiguratorTextfield";
