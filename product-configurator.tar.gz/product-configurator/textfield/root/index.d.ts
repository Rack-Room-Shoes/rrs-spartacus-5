/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/product-configurator/textfield/root" />
export * from './public_api';
