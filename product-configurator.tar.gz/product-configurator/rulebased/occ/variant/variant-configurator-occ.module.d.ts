import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@spartacus/core";
export declare class VariantConfiguratorOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VariantConfiguratorOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VariantConfiguratorOccModule, never, [typeof i1.CommonModule, typeof i2.ConfigModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VariantConfiguratorOccModule>;
}
