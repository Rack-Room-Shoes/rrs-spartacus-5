import { RoutingConfig } from '@spartacus/core';
export declare const defaultCpqInteractiveRoutingConfig: RoutingConfig;
