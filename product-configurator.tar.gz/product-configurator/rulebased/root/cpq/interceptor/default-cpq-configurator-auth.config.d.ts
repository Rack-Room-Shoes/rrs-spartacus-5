import { CpqConfiguratorAuthConfig } from './cpq-configurator-auth.config';
export declare const defaultCpqConfiguratorAuthConfig: CpqConfiguratorAuthConfig;
