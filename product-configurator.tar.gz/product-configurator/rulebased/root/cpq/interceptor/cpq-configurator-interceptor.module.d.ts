import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare class CpqConfiguratorInterceptorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorInterceptorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CpqConfiguratorInterceptorModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CpqConfiguratorInterceptorModule>;
}
