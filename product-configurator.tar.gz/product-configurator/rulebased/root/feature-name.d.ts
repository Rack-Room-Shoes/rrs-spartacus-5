export declare const PRODUCT_CONFIGURATOR_RULEBASED_FEATURE = "productConfiguratorRulebased";
