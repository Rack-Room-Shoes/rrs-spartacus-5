import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const configuratorTranslations: TranslationResources;
export declare const configuratorTranslationChunksConfig: TranslationChunksConfig;
