/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/product-configurator/common/assets" />
export * from './public_api';
