import * as i0 from "@angular/core";
export declare class CommonConfiguratorOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonConfiguratorOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonConfiguratorOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonConfiguratorOccModule>;
}
