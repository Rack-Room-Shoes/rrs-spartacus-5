export * from './common-configurator-occ.module';
