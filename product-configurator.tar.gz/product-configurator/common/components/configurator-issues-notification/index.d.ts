export * from './configurator-issues-notification.component';
export * from './configurator-issues-notification.module';
