export * from './configure-product.component';
export * from './configure-product.module';
