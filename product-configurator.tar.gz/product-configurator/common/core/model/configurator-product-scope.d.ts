export declare enum ConfiguratorProductScope {
    CONFIGURATOR = "configurator",
    CONFIGURATOR_PRODUCT_CARD = "configuratorProductCard"
}
