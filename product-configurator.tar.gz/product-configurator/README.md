# Spartacus Product Configurator

`@spartacus/product-configurator` is a package that you can include in your application, which allows you to use different product configurators.

For more information, see [Spartacus](https://github.com/SAP/spartacus).
