import { SmartEditConfig } from './smart-edit-config';
export declare const defaultSmartEditConfig: SmartEditConfig;
