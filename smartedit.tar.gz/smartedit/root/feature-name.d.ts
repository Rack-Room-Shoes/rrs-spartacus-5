export declare const SMART_EDIT_FEATURE = "smartEdit";
