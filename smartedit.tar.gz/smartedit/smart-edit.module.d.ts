import * as i0 from "@angular/core";
import * as i1 from "@spartacus/smartedit/core";
export declare class SmartEditModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SmartEditModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SmartEditModule, never, [typeof i1.SmartEditCoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SmartEditModule>;
}
