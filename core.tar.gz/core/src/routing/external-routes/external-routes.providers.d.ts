import { ExternalRoutesService } from './external-routes.service';
export declare function addExternalRoutesFactory(service: ExternalRoutesService): () => void;
