export declare const effects: any[];
export * from './router.effect';
