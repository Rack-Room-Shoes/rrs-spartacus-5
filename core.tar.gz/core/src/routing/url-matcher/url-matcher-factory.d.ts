import { Route, UrlMatcher } from '@angular/router';
export declare type UrlMatcherFactory = (route: Route) => UrlMatcher;
