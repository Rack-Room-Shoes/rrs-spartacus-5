import { SiteContextConfig } from './site-context-config';
export declare function defaultSiteContextConfigFactory(): SiteContextConfig;
