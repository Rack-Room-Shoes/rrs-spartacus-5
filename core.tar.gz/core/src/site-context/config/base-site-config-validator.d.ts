import { SiteContextConfig } from './site-context-config';
export declare function baseSiteConfigValidator(config: SiteContextConfig): "Please configure context.parameters.baseSite before using storefront library!" | undefined;
