import { SiteContextActions } from '../actions/index';
import { CurrenciesState } from '../state';
export declare const initialState: CurrenciesState;
export declare function reducer(state: CurrenciesState | undefined, action: SiteContextActions.CurrenciesAction): CurrenciesState;
