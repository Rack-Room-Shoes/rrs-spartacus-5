export declare const LANGUAGE_CONTEXT_ID = "language";
export declare const CURRENCY_CONTEXT_ID = "currency";
export declare const BASE_SITE_CONTEXT_ID = "baseSite";
export declare const THEME_CONTEXT_ID = "theme";
