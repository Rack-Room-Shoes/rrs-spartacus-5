import { I18nConfig } from './i18n-config';
export declare const defaultI18nConfig: I18nConfig;
