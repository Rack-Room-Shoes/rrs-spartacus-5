import { Provider } from '@angular/core';
export declare const i18nextProviders: Provider[];
