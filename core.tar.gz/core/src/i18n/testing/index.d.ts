export * from './i18n-testing.module';
export * from './mock-translate.pipe';
export * from './mock-date.pipe';
