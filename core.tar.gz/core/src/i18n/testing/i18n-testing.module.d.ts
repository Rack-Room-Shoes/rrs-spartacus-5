import * as i0 from "@angular/core";
import * as i1 from "./mock-translate.pipe";
import * as i2 from "./mock-date.pipe";
export declare class I18nTestingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nTestingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<I18nTestingModule, [typeof i1.MockTranslatePipe, typeof i2.MockDatePipe], never, [typeof i1.MockTranslatePipe, typeof i2.MockDatePipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<I18nTestingModule>;
}
