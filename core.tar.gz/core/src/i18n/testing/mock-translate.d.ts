export declare function mockTranslate(key: string | undefined, options?: any): string | undefined;
