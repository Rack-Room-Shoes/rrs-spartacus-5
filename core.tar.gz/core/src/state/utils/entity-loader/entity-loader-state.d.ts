import { EntityState } from '../entity/entity-state';
import { LoaderState } from '../loader/loader-state';
export declare type EntityLoaderState<T> = EntityState<LoaderState<T>>;
