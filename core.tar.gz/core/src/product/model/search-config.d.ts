export interface SearchConfig {
    pageSize?: number;
    currentPage?: number;
    sort?: string;
}
