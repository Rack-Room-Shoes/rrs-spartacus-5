import { GlobalMessageConfig } from './global-message-config';
export declare const defaultGlobalMessageConfig: GlobalMessageConfig;
