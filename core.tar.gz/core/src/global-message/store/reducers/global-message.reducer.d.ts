import { GlobalMessageActions } from '../actions/index';
import { GlobalMessageState } from '../global-message-state';
export declare const initialState: GlobalMessageState;
export declare function reducer(state: GlobalMessageState | undefined, action: GlobalMessageActions.GlobalMessageAction): GlobalMessageState;
