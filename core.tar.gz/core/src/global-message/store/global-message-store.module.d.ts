import * as i0 from "@angular/core";
import * as i1 from "../../state/state.module";
import * as i2 from "@ngrx/store";
export declare class GlobalMessageStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalMessageStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GlobalMessageStoreModule, never, [typeof i1.StateModule, typeof i2.StoreFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GlobalMessageStoreModule>;
}
