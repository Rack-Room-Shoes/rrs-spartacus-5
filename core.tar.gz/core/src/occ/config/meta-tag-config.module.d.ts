import { ModuleWithProviders } from '@angular/core';
import * as i0 from "@angular/core";
export declare class MetaTagConfigModule {
    static forRoot(): ModuleWithProviders<MetaTagConfigModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MetaTagConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MetaTagConfigModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MetaTagConfigModule>;
}
