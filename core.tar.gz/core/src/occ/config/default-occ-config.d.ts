import { OccConfig } from './occ-config';
export declare const defaultOccConfig: OccConfig;
