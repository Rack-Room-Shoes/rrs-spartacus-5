import { OccConfig } from './occ-config';
export declare function occConfigValidator(config: OccConfig): "Please configure backend.occ.baseUrl before using storefront library!" | undefined;
