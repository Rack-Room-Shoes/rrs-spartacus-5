import './product-occ-config';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare class ProductOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductOccModule>;
}
