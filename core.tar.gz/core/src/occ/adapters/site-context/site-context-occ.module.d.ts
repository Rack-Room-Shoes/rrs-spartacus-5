import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare class SiteContextOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SiteContextOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SiteContextOccModule>;
}
