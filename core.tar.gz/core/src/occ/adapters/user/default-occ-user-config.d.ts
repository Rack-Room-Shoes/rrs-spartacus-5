import { OccConfig } from '../../config/occ-config';
export declare const defaultOccUserConfig: OccConfig;
