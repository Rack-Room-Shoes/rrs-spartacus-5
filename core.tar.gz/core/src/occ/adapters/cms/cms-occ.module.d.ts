import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare class CmsOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CmsOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CmsOccModule>;
}
