import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "../../../config/config.module";
export declare class CostCenterOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CostCenterOccModule, never, [typeof i1.CommonModule, typeof i2.ConfigModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CostCenterOccModule>;
}
