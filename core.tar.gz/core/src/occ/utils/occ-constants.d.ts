export declare const OCC_USER_ID_CURRENT = "current";
export declare const OCC_USER_ID_ANONYMOUS = "anonymous";
export declare const OCC_USER_ID_GUEST = "guest";
export declare const OCC_CART_ID_CURRENT = "current";
