import { AnonymousConsentsConfig } from './anonymous-consents-config';
export declare const defaultAnonymousConsentsConfig: AnonymousConsentsConfig;
