import * as AnonymousConsentsActions from './anonymous-consents-group';
export { AnonymousConsentsActions };
