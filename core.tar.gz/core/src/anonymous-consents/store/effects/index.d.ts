export declare const effects: any[];
export * from './anonymous-consents.effect';
