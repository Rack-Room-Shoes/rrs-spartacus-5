import { AnonymousConsentsActions } from '../actions/index';
export declare const initialState = false;
export declare function reducer(state: boolean | undefined, action: AnonymousConsentsActions.ToggleAnonymousConsentTemplatesUpdated): boolean;
