import * as AnonymousConsentsSelectors from './anonymous-consents-group.selectors';
export { AnonymousConsentsSelectors };
