import { ModuleWithProviders } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PageMetaModule {
    static forRoot(): ModuleWithProviders<PageMetaModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageMetaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PageMetaModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PageMetaModule>;
}
