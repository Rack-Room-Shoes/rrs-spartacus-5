import { PageMetaConfig } from './page-meta.config';
export declare const defaultPageMetaConfig: PageMetaConfig;
