export interface ContentSlotComponentData {
    uid?: string;
    typeCode?: string;
    flexType?: string;
    properties?: any;
}
