import { CmsLinkComponent } from '../../model/cms.model';
export interface NodeItem {
    [id_type: string]: CmsLinkComponent;
}
