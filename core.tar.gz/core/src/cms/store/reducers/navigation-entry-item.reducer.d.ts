import { NodeItem } from '../../model/node-item.model';
import { CmsActions } from '../actions/index';
export declare const initialState: NodeItem | undefined;
export declare function reducer(state: NodeItem | undefined, action: CmsActions.CmsNavigationEntryItemAction): NodeItem | undefined;
