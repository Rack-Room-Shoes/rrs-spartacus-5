import { CmsConfig } from './cms-config';
export declare const defaultCmsModuleConfig: CmsConfig;
