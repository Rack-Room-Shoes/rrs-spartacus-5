# Spartacus Setup

Spartacus Setup includes features that makes Spartacus and it's setup easier and streamlined.

The library is still under development, main goal is to provide:

- **@spartacus/setup/recipies**: To provide common Spartacus recipes with default module set and configuration 

- **@spartacus/setup/schematics**: To provide schematics that will take care configuring different Spartacus feature libraries to work seamlessly together.


For more information please see our [documentation](https://help.sap.com/docs/SAP_COMMERCE_COMPOSABLE_STOREFRONT).
