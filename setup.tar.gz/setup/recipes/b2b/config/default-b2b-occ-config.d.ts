import { OccConfig } from '@spartacus/core';
export declare const defaultB2bOccConfig: OccConfig;
