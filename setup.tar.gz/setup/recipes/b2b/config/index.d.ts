export * from './default-b2b-occ-config';
