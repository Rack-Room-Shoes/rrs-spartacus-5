import { Request } from 'express';
export declare function getRequestOrigin(req: Request): string;
