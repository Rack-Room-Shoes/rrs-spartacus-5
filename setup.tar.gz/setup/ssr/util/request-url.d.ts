import { Request } from 'express';
export declare function getRequestUrl(req: Request): string;
