export { NgExpressEngineDecorator } from './ng-express-engine-decorator';
