/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/setup/ssr" />
export * from './public_api';
