/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/product/image-zoom" />
export * from './public_api';
