export * from './product-image-zoom.module';
