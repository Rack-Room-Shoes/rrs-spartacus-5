import * as i0 from "@angular/core";
import * as i1 from "./product-image-zoom/product-image-zoom.module";
export declare class ProductImageZoomComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductImageZoomComponentsModule, never, [typeof i1.ProductImageZoomModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductImageZoomComponentsModule>;
}
