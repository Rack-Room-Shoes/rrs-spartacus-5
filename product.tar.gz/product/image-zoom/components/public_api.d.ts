export * from './product-image-zoom-components.module';
export * from './product-image-zoom/index';
