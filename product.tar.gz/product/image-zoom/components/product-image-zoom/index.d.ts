export * from './product-image-zoom.module';
export * from './product-image-zoom-view/product-image-zoom-view.component';
export * from './product-image-zoom-trigger/product-image-zoom-trigger.component';
export * from './product-image-zoom-thumbnails/product-image-zoom-thumbnails.component';
export * from './product-image-zoom-product-images/product-image-zoom-product-images.component';
export * from './default-product-image-zoom-layout.config';
export * from './product-image-zoom-dialog/product-image-zoom-dialog.component';
