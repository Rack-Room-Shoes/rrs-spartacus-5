export declare const en: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            close: string;
        };
    };
};
