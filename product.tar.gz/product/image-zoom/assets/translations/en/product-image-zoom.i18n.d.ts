export declare const productImageZoomTrigger: {
    expand: string;
};
export declare const productImageZoomDialog: {
    close: string;
};
export declare const productImageZoom: {
    productImageZoomTrigger: {
        expand: string;
    };
    productImageZoomDialog: {
        close: string;
    };
};
