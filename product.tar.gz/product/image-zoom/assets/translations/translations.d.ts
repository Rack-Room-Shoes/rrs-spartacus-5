import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const productImageZoomTranslations: TranslationResources;
export declare const productImageZoomTranslationChunksConfig: TranslationChunksConfig;
