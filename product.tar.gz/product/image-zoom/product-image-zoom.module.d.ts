import * as i0 from "@angular/core";
import * as i1 from "@spartacus/product/image-zoom/components";
export declare class ProductImageZoomModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductImageZoomModule, never, [typeof i1.ProductImageZoomComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductImageZoomModule>;
}
