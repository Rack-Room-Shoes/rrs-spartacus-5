import * as i0 from "@angular/core";
export declare function defaultImageZoomComponentsConfig(): {
    featureModules: {
        productImageZoom: {
            cmsComponents: string[];
        };
    };
};
export declare class ProductImageZoomRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductImageZoomRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductImageZoomRootModule>;
}
