import '@spartacus/storefront';
declare module '@spartacus/storefront' {
    const enum LAUNCH_CALLER {
        PRODUCT_IMAGE_ZOOM = "PRODUCT_IMAGE_ZOOM"
    }
}
