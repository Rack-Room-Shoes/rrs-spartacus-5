import { ImageGroup } from '@spartacus/core';
export interface ThumbnailsGroup {
    container: ImageGroup;
}
