export declare const PRODUCT_IMAGE_ZOOM_FEATURE = "productImageZoom";
