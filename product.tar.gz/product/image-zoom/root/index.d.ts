/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/product/image-zoom/root" />
export * from './public_api';
