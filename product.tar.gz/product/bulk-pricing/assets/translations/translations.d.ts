import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const bulkPricingTranslations: TranslationResources;
export declare const bulkPricingTranslationChunksConfig: TranslationChunksConfig;
