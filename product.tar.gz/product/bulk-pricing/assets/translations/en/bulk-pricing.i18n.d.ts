export declare const bulkPricingTable: {
    quantity: string;
    price: string;
    discount: string;
};
export declare const bulkPricing: {
    bulkPricingTable: {
        quantity: string;
        price: string;
        discount: string;
    };
};
