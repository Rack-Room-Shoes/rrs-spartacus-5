export declare const en: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};
