export * from './bulk-pricing-table.module';
export * from './bulk-pricing-table.component';
