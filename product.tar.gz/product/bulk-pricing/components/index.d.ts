/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/product/bulk-pricing/components" />
export * from './public_api';
