import '@spartacus/core';
declare module '@spartacus/core' {
    const enum ProductScope {
        BULK_PRICES = "bulkPrices"
    }
}
