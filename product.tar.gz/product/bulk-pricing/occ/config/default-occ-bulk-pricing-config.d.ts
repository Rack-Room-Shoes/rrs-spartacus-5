import { OccConfig } from '@spartacus/core';
export declare const defaultOccBulkPricingConfig: OccConfig;
