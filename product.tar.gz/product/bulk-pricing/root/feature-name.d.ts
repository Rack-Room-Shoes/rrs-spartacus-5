export declare const PRODUCT_BULK_PRICING_FEATURE = "productBulkPricing";
