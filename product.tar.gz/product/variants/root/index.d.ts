/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/product/variants/root" />
export * from './public_api';
