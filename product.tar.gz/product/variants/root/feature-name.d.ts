export declare const PRODUCT_VARIANTS_FEATURE = "productVariants";
