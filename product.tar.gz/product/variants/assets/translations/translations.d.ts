import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const productVariantsTranslations: TranslationResources;
export declare const productVariantsTranslationChunksConfig: TranslationChunksConfig;
