export declare const productVariants: {
    productVariants: {
        style: string;
        selectedStyle: string;
        size: string;
        color: string;
        sizeGuideLabel: string;
    };
};
