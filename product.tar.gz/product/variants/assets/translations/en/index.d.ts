export declare const en: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};
