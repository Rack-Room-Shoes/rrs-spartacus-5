export * from './occ-asm.adapter';
