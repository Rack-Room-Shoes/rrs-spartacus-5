import { OccConfig } from '@spartacus/core';
export declare const defaultOccAsmConfig: OccConfig;
