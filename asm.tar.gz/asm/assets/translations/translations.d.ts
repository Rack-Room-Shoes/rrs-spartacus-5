import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const asmTranslations: TranslationResources;
export declare const asmTranslationChunksConfig: TranslationChunksConfig;
