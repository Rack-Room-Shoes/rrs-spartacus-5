import * as i0 from "@angular/core";
import * as i1 from "./asm-loader.module";
export declare class AsmRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmRootModule, never, [typeof i1.AsmLoaderModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmRootModule>;
}
