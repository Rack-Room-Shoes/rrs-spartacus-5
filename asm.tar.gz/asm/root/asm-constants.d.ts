export declare const ASM_ENABLED_LOCAL_STORAGE_KEY = "asm_enabled";
