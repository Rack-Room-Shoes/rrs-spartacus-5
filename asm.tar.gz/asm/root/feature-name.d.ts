export declare const ASM_FEATURE = "asm";
