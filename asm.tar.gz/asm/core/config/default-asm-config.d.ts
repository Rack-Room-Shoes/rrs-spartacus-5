import { AsmConfig } from './asm-config';
export declare const defaultAsmConfig: AsmConfig;
