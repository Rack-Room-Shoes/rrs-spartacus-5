import * as i0 from "@angular/core";
export declare class StoreFinderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderComponent, "cx-store-finder", never, {}, {}, never, never, false>;
}
