export declare enum LocationDisplayMode {
    LIST_VIEW = "listView",
    MAP_VIEW = "mapView"
}
