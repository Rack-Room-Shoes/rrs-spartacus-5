import * as i0 from "@angular/core";
export declare class StoreFinderHeaderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderHeaderComponent, "cx-store-finder-header", never, {}, {}, never, never, false>;
}
