export declare const STORE_FINDER_FEATURE = "storeFinder";
