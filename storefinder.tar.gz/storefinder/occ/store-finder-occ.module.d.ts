import * as i0 from "@angular/core";
export declare class StoreFinderOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StoreFinderOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StoreFinderOccModule>;
}
