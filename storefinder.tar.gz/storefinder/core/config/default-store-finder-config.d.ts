import { StoreFinderConfig } from './store-finder-config';
export declare const defaultStoreFinderConfig: StoreFinderConfig;
