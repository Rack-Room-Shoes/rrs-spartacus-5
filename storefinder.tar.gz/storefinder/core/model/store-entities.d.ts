import { PointOfService } from '@spartacus/core';
export interface StoreEntities {
    pointOfServices?: Array<PointOfService>;
}
