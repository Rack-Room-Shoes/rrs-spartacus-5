import { StoreFinderActions } from '../actions/index';
import { FindStoresState } from '../store-finder-state';
export declare const initialState: FindStoresState;
export declare function findStoresReducer(state: FindStoresState, action: StoreFinderActions.FindStoresAction): FindStoresState;
