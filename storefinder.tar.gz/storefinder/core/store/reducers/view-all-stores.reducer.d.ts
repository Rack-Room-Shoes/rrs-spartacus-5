import { StoreFinderActions } from '../actions/index';
import { ViewAllStoresState } from '../store-finder-state';
export declare const initialState: ViewAllStoresState;
export declare function viewAllStoresReducer(state: ViewAllStoresState, action: StoreFinderActions.ViewAllStoresAction): ViewAllStoresState;
