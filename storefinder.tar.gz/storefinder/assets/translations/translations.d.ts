import { TranslationChunksConfig, TranslationResources } from '@spartacus/core';
export declare const storeFinderTranslations: TranslationResources;
export declare const storeFinderTranslationChunksConfig: TranslationChunksConfig;
