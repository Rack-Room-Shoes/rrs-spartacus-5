import { CdsConfig } from './cds-config';
export declare const DEFAULT_CDS_CONFIG: CdsConfig;
