import { CdsConfig } from './cds-config';
export declare function cdsConfigValidator(config: CdsConfig): string | void;
