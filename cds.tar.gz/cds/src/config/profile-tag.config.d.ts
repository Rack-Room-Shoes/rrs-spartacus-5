export interface ProfileTagConfig {
    javascriptUrl?: string;
    configUrl?: string;
    allowInsecureCookies?: boolean;
    gtmId?: string;
}
