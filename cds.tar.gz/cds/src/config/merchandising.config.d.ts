export interface MerchandisingConfig {
    defaultCarouselViewportThreshold?: number;
}
