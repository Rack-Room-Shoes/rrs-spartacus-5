export * from './profile-tag.model';
