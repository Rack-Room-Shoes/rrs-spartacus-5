import * as i0 from "@angular/core";
import * as i1 from "./profile-tag.component";
import * as i2 from "@angular/common";
export declare class ProfileTagCmsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileTagCmsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProfileTagCmsModule, [typeof i1.ProfileTagComponent], [typeof i2.CommonModule], [typeof i1.ProfileTagComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProfileTagCmsModule>;
}
