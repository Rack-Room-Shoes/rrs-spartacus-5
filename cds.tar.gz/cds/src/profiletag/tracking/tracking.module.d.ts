import * as i0 from "@angular/core";
export declare class TrackingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TrackingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TrackingModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TrackingModule>;
}
