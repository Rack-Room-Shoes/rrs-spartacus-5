import * as i0 from "@angular/core";
import * as i1 from "./cms-components/profile-tag-cms.module";
export declare class ProfileTagModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileTagModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProfileTagModule, never, [typeof i1.ProfileTagCmsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProfileTagModule>;
}
