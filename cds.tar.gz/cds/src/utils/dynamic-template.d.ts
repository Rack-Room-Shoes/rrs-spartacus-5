export declare class DynamicTemplate {
    static resolve(templateString: string, templateVariables: Object): string;
}
