export * from './cds-merchandising-strategy.adapter';
