export interface MerchandisingSiteContext {
    site?: string;
    language?: string;
}
