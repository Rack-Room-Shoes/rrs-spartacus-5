export interface MerchandisingMetadata {
    [metadataKey: string]: any;
}
