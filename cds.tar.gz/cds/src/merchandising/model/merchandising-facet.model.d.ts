export interface MerchandisingFacet {
    code: string;
    value: string;
}
