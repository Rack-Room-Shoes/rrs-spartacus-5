export interface MerchandisingUserContext {
    category?: string;
    products?: string[];
    facets?: string;
    consentReference?: string;
    searchPhrase?: string;
}
