import * as i0 from "@angular/core";
import * as i1 from "./attributes.directive";
import * as i2 from "@angular/common";
export declare class AttributesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AttributesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AttributesModule, [typeof i1.AttributesDirective], [typeof i2.CommonModule], [typeof i1.AttributesDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AttributesModule>;
}
