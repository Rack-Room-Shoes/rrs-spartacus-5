import * as i0 from "@angular/core";
import * as i1 from "./cms-components/merchandising-carousel-cms.module";
export declare class MerchandisingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MerchandisingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MerchandisingModule, never, [typeof i1.MerchandisingCarouselCmsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MerchandisingModule>;
}
