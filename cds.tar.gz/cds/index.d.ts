/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@spartacus/cds" />
export * from './public_api';
